// app/(dashboard)/appointments/page.tsx
"use client"

import React, { useState } from 'react';
// import { useRouter } from 'next/navigation';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import { getAppointments } from '@/app/db/db_manager';


const AppointmentsDashboardPage = () => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [events, setEvents] = useState<{id: number, title: string, start: string}[]>([]);
    const [loading, setLoading] = useState(false);
    // const router = useRouter();

    // Load appointments
    React.useEffect(() => {
        const fetchAppointments = async () => {
            setLoading(true);
            try {

                getAppointments()
                    .then((appointments) => {
                        setEvents(appointments);
                    });

            } catch (error) {
                console.error('Failed to load appointments:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchAppointments();
    }, []);

    const handleDateSelect = () => {
        setIsModalOpen(true);
    };

    const handleEventClick = (clickInfo) => {
        alert(`Запис: ${clickInfo.event.title}`);
    };

    // const handleAddAppointment = async (values) => {
    //     try {
    //         setLoading(true);
    //         await createAppointment({
    //             clientId: values.clientId,
    //             serviceId: values.serviceId,
    //             appointmentDate: values.date.toISOString(),
    //         });
    //         setIsModalOpen(false);
    //         router.refresh();
    //     } catch (error) {
    //         console.error('Failed to create appointment:', error);
    //     } finally {
    //         setLoading(false);
    //     }
    // };

    return (
        <div className="flex flex-row h-[90vh]">
            {/*<div>*/}
            {/*    <h1>Календар записів</h1>*/}
            {/*    <Button onClick={() => setIsModalOpen(true)}>*/}
            {/*        Додати запис*/}
            {/*    </Button>*/}
            {/*</div>*/}

            <div className="w-full grid">
                <FullCalendar
                    plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
                    initialView="dayGridMonth"
                    editable={false}
                    selectable={true}
                    select={handleDateSelect}
                    // events={events}
                    eventClick={handleEventClick}
                />
            </div>

            {/*<Modal*/}
            {/*    title="Додати запис"*/}
            {/*    open={isModalOpen}*/}
            {/*    onCancel={() => setIsModalOpen(false)}*/}
            {/*    footer={null}*/}
            {/*>*/}
            {/*    <Form onFinish={handleAddAppointment} layout="vertical">*/}
            {/*        <Form.Item name="clientId" label="Клієнт" rules={[{ required: true, message: 'Оберіть клієнта' }]}>*/}
            {/*            <Select placeholder="Оберіть клієнта">*/}
            {/*                /!* Replace options with real data *!/*/}
            {/*                <Select.Option value={1}>Клієнт 1</Select.Option>*/}
            {/*                <Select.Option value={2}>Клієнт 2</Select.Option>*/}
            {/*            </Select>*/}
            {/*        </Form.Item>*/}
            {/*        <Form.Item name="serviceId" label="Послуга" rules={[{ required: true, message: 'Оберіть послугу' }]}>*/}
            {/*            <Select placeholder="Оберіть послугу">*/}
            {/*                /!* Replace options with real data *!/*/}
            {/*                <Select.Option value={1}>Послуга 1</Select.Option>*/}
            {/*                <Select.Option value={2}>Послуга 2</Select.Option>*/}
            {/*            </Select>*/}
            {/*        </Form.Item>*/}
            {/*        <Form.Item name="date" label="Дата і час" rules={[{ required: true, message: 'Оберіть дату і час' }]}>*/}
            {/*            <DatePicker showTime format="YYYY-MM-DD HH:mm" />*/}
            {/*        </Form.Item>*/}
            {/*        <Form.Item>*/}
            {/*            <Button type="primary" htmlType="submit" loading={loading}>*/}
            {/*                Додати*/}
            {/*            </Button>*/}
            {/*        </Form.Item>*/}
            {/*    </Form>*/}
            {/*</Modal>*/}
        </div>
    );
};

export default AppointmentsDashboardPage;
