"use client"

import React, { useEffect, useState } from "react";
import { ColumnDef } from "@tanstack/react-table";
import { Check, ChevronsUpDown, MoreHorizontal } from "lucide-react";
import { cn } from "@/lib/utils";

// Імпорт компонентів UI
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

import { Label } from "@/components/ui/label";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
    DialogFooter
} from "@/components/ui/dialog";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuSeparator,
    DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import {
    Pagination,
    PaginationContent,
    PaginationEllipsis,
    PaginationItem,
    PaginationLink,
    PaginationPrevious,
    PaginationNext
} from "@/components/ui/pagination";
import {
    Popover,
    PopoverContent,
    PopoverTrigger
} from "@/components/ui/popover";
import {
    Command,
    CommandEmpty,
    CommandGroup,
    CommandInput,
    CommandItem,
    CommandList
} from "@/components/ui/command";

// Типи
type Client = {
    id: number;
    fullName: string;
    email: string;
    phone: string;
    contactInfo?: string;
    totalVisits: number;
    totalSpent: number;
};

export default function ClientsDashboardPage() {
    // Стани для даних
    const [clients, setClients] = useState<Client[]>([]);
    const [searchQuery, setSearchQuery] = useState("");

    // Стани для пагінації
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [pageSize, setPageSize] = useState(10);

    // Стани для редагування
    const [isEditing, setIsEditing] = useState(false);
    const [editingClientId, setEditingClientId] = useState<number | null>(null);
    const [formData, setFormData] = useState<Partial<Client>>({
        fullName: "",
        email: "",
        phone: "",
        contactInfo: ""
    });

    // Варіанти кількості елементів на сторінці
    const pageSizeOptions = [
        { value: "10", label: "10" },
        { value: "20", label: "20" },
        { value: "30", label: "30" },
        { value: "50", label: "50" }
    ];

    const [pageSizeOpen, setPageSizeOpen] = useState(false);
    const [pageSizeValue, setPageSizeValue] = useState("10");

    useEffect(() => {
        fetchClients(currentPage, pageSize);
    }, [currentPage, pageSize]);

    const fetchClients = async (page: number, pageSize: number) => {
        try {
            // TODO: Замінити на реальний виклик API
            // const response = await getClientsWithPagination(page, pageSize);
            // setClients(response.clients);
            // setTotalPages(response.totalPages);
            console.log("Fetch clients");
        } catch (error) {
            console.error("Помилка при завантаженні клієнтів:", error);
        }
    };

    const handleUpdateClient = async () => {
        if (!editingClientId) return;

        try {
            // TODO: Замінити на реальний виклик оновлення клієнта
            // await updateClient(editingClientId, formData);
            await fetchClients(currentPage, pageSize);
            resetForm();
        } catch (error) {
            console.error("Помилка при оновленні клієнта:", error);
        }
    };

    const resetForm = () => {
        setFormData({
            fullName: "",
            email: "",
            phone: "",
            contactInfo: ""
        });
        setIsEditing(false);
        setEditingClientId(null);
    };

    const startEditing = (client: Client) => {
        setIsEditing(true);
        setEditingClientId(client.id);
        setFormData({
            fullName: client.fullName,
            email: client.email,
            phone: client.phone,
            contactInfo: client.contactInfo
        });
    };

    // Генерація сторінок для пагінації
    const generatePageNumbers = () => {
        const pages = [];
        const maxPagesToShow = 5;
        let startPage = Math.max(1, currentPage - Math.floor(maxPagesToShow / 2));
        const endPage = Math.min(totalPages, startPage + maxPagesToShow - 1);

        if (endPage - startPage + 1 < maxPagesToShow) {
            startPage = Math.max(1, endPage - maxPagesToShow + 1);
        }

        for (let i = startPage; i <= endPage; i++) {
            pages.push(i);
        }

        return pages;
    };

    const columns: ColumnDef<Client>[] = [
        {
            accessorKey: "id",
            header: "ID",
        },
        {
            accessorKey: "fullName",
            header: ({ column }) => (
                <Button
                    variant="ghost"
                    onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
                >
                    ПІБ
                    <ChevronsUpDown className="ml-2 h-4 w-4" />
                </Button>
            ),
        },
        {
            accessorKey: "email",
            header: "Email",
        },
        {
            accessorKey: "phone",
            header: "Телефон",
        },
        {
            accessorKey: "totalVisits",
            header: "Візити",
        },
        {
            accessorKey: "totalSpent",
            header: "Витрачено",
            cell: ({ getValue }) => {
                const value = getValue() as number;
                return `${value.toFixed(2)} грн`;
            }
        },
        {
            header: "Дії",
            id: "actions",
            cell: ({ row }) => {
                const client = row.original;

                return (
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                                <MoreHorizontal className="h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => startEditing(client)}>
                                Редагувати
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-red-900">
                                Видалити
                            </DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                );
            },
        },
    ];

    return (
        <div className="w-full flex flex-col space-x-3 p-4">
            <div className="flex items-center mb-4 space-x-5 p-4">
                <h1 className="text-2xl font-bold">Клієнти</h1>
                <Button onClick={() => {/* TODO: Додати логіку створення нового клієнта */}}>
                    Новий клієнт
                </Button>
            </div>

            <div className="flex items-center py-4 space-x-4">
                <Input
                    placeholder="Пошук клієнта..."
                    value={searchQuery}
                    onChange={(event) => setSearchQuery(event.target.value)}
                    className="max-w-sm"
                />

                <Popover open={pageSizeOpen} onOpenChange={setPageSizeOpen}>
                    <PopoverTrigger asChild>
                        <Button
                            variant="outline"
                            role="combobox"
                            aria-expanded={pageSizeOpen}
                            className="w-[200px] justify-between"
                        >
                            {pageSizeValue
                                ? pageSizeOptions.find((option) => option.value === pageSizeValue)?.label
                                : "Кількість на сторінці"}
                            <ChevronsUpDown className="opacity-50" />
                        </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-[200px] p-0">
                        <Command>
                            <CommandInput placeholder="Обрати кількість..." />
                            <CommandList>
                                <CommandEmpty>Не обрано</CommandEmpty>
                                <CommandGroup>
                                    {pageSizeOptions.map((option) => (
                                        <CommandItem
                                            key={option.value}
                                            value={option.value}
                                            onSelect={(currentValue) => {
                                                setPageSizeValue(currentValue);
                                                setPageSize(Number(currentValue));
                                                setPageSizeOpen(false);
                                            }}
                                        >
                                            {option.label}
                                            <Check
                                                className={cn(
                                                    "ml-auto",
                                                    pageSizeValue === option.value ? "opacity-100" : "opacity-0"
                                                )}
                                            />
                                        </CommandItem>
                                    ))}
                                </CommandGroup>
                            </CommandList>
                        </Command>
                    </PopoverContent>
                </Popover>
            </div>

            <DataTable
                columns={columns}
                data={clients.filter(client =>
                    client.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    client.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    client.phone.toLowerCase().includes(searchQuery.toLowerCase())
                )}
            />

            <Pagination>
                <PaginationContent>
                    <PaginationItem>
                        <PaginationPrevious
                            onClick={() => setCurrentPage(currentPage - 1)}
                            isActive={currentPage === 1}
                        />
                    </PaginationItem>
                    {generatePageNumbers().map(page => (
                        <PaginationItem key={page}>
                            <PaginationLink
                                href="#"
                                onClick={() => setCurrentPage(page)}
                                isActive={page === currentPage}
                            >
                                {page}
                            </PaginationLink>
                        </PaginationItem>
                    ))}
                    <PaginationItem>
                        <PaginationEllipsis />
                    </PaginationItem>
                    <PaginationItem>
                        <PaginationNext
                            onClick={() => setCurrentPage(currentPage + 1)}
                            isActive={currentPage === totalPages}
                        />
                    </PaginationItem>
                </PaginationContent>
            </Pagination>

            <Dialog open={isEditing} onOpenChange={(open) => !open && resetForm()}>
                <DialogContent className="sm:max-w-[600px]">
                    <DialogHeader>
                        <DialogTitle>Редагування клієнта</DialogTitle>
                        <DialogDescription>
                            Змініть дані клієнта
                        </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="fullName" className="text-right">
                                ПІБ
                            </Label>
                            <Input
                                id="fullName"
                                value={formData.fullName || ""}
                                onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                                className="col-span-3"
                            />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="email" className="text-right">
                                Email
                            </Label>
                            <Input
                                id="email"
                                type="email"
                                value={formData.email || ""}
                                onChange={(e) => setFormData({...formData, email: e.target.value})}
                                className="col-span-3"
                            />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="phone" className="text-right">
                                Телефон
                            </Label>
                            <Input
                                id="phone"
                                value={formData.phone || ""}
                                onChange={(e) => setFormData({...formData, phone: e.target.value})}
                                className="col-span-3"
                            />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="contactInfo" className="text-right">
                                Додаткова інформація
                            </Label>
                            <Input
                                id="contactInfo"
                                value={formData.contactInfo || ""}
                                onChange={(e) => setFormData({...formData, contactInfo: e.target.value})}
                                className="col-span-3"
                                placeholder="Додаткові контактні дані"
                            />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={resetForm}>
                            Скасувати
                        </Button>
                        <Button type="button" onClick={handleUpdateClient}>
                            Зберегти
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}