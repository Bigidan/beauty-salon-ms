import React from 'react';

const DiscountsDashboardPage = () => {
    return (
        <div>

        </div>
    );
};

export default DiscountsDashboardPage;
