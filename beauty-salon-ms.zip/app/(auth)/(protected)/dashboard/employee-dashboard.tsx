import React from 'react';

const EmployeeDashboardPage = () => {
    return (
        <div>

        </div>
    );
};

export default EmployeeDashboardPage;
