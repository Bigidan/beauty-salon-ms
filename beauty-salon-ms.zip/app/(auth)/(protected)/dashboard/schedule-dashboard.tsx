import React from 'react';

const ScheduleDashboardPage = () => {
    return (
        <div>
            
        </div>
    );
};

export default ScheduleDashboardPage;
