import React from 'react';

const StatsDashboardPage = () => {
    return (
        <div>
Статистика
        </div>
    );
};

export default StatsDashboardPage;
