"use server";

import { eq, and, sum, sql } from 'drizzle-orm';
import { db } from './index'; // Припускаємо, що це ваша ініціалізація drizzle ORM
import {clientsTable, appointmentsTable, discountsTable, servicesTable, visitHistoryTable, clientDiscountsTable, userTable} from './schema';
import { InferInsertModel, InferSelectModel } from 'drizzle-orm';

// --- Типи для моделі клієнтів ---
type ClientUpdate = Partial<InferInsertModel<typeof clientsTable>>;
type Discount = InferSelectModel<typeof discountsTable>;



// --- Функції для роботи з користувачами ---

/**
 * Видалення користувача
 * @param userId ID користувача
 */
export async function deleteUser(userId: number) {
    return db.delete(userTable).where(eq(userTable.userId, userId));
}

/**
 * Отримання списку користувачів враховуючи пагінацію
 * @param page Сторінка на якій знаходиться адміністратор
 * @param pageSize Кількість користувачів на сторінці
 */
export async function getUsersWithPagination(page: number = 1, pageSize: number = 20) {
    const offset = (page - 1) * pageSize;

    const [users, totalUsersCount] = await Promise.all([
        db
            .select()
            .from(userTable)
            .limit(pageSize)
            .offset(offset),
        db
            .select({ count: db.$count(userTable) })
            .from(userTable)
            .then(result => result[0].count)
    ]);

    return {
        users,
        totalPages: Math.ceil(totalUsersCount / pageSize),
        currentPage: page,
        totalUsers: totalUsersCount
    };
}

/**
 * Отримання списку користувачів враховуючи пагінацію
 * @param userId Айді користувача для оновлення
 * @param role Нова роль користувача
 * @param name Нове ім'я користувача
 * @param email Нова пошта користувача
 * @param phone Новий номер користувача
 */
export async function updateUser(userId: number, role: number, name: string, email: string, phone: string) {
    return db.update(userTable)
        .set({
            role: role,
            name: name,
            email: email,
            phone: phone,
        })
        .where(eq(userTable.userId, userId)).returning({ id: userTable.userId });
}


// --- Функції для роботи з клієнтами ---

/**
 * Отримати всі дані про клієнта за його ID
 * @param clientId ID клієнта
 */
export async function getClientById(clientId: number) {
    return db.select().from(clientsTable).where(eq(clientsTable.clientId, clientId)).get();
}

/**
 * Додати нового клієнта
 * @param fullName ПІБ клієнта
 * @param email Email клієнта
 * @param phone Телефон клієнта
 */
export async function addClient(fullName: string, email: string, phone: string, contactInfo?: string) {
    return db.insert(clientsTable).values({
        fullName,
        email,
        phone,
        contactInfo: contactInfo || '',
        totalVisits: 0,
        totalSpent: 0
    }).run();
}

/**
 * Оновити дані клієнта
 * @param clientId ID клієнта
 * @param updates Об'єкт оновлення
 */
export async function updateClient(clientId: number, updates: ClientUpdate) {
    return db.update(clientsTable).set(updates).where(eq(clientsTable.clientId, clientId)).run();
}

// --- Функції для запису на послуги ---

/**
 * Запис клієнта на послугу
 * @param clientId ID клієнта
 * @param serviceId ID послуги
 * @param appointmentDate Дата запису
 * @param discountId (необов'язково) ID знижки
 */
export async function bookAppointment(clientId: number, serviceId: number, appointmentDate: Date, discountId?: number) {
    const service = await db.select().from(servicesTable).where(eq(servicesTable.id, serviceId)).get();
    if (!service) throw new Error('Послуга не знайдена');

    let finalPrice = service.price;

    // Якщо застосовується знижка
    if (discountId) {
        const discount = await db.select().from(discountsTable).where(eq(discountsTable.id, discountId)).get();
        if (discount && discount.isActive) {
            finalPrice = applyDiscount(service.price, discount);
        }
    }

    return db.insert(appointmentsTable).values({
        clientId,
        serviceId,
        appointmentDate: appointmentDate,
        status: 'SCHEDULED',
        price: finalPrice,
        discountId: discountId || null
    }).run();
}

/**
 * Отримати записи клієнта
 * @param clientId ID клієнта
 */
export async function getClientAppointments(clientId: number) {
    return db.select().from(appointmentsTable).where(eq(appointmentsTable.clientId, clientId)).all();
}

/**
 * Оновити статус запису
 * @param appointmentId ID запису
 * @param status Новий статус
 */
export async function updateAppointmentStatus(appointmentId: number, status: 'SCHEDULED' | 'COMPLETED' | 'CANCELLED') {
    return db.update(appointmentsTable).set({ status }).where(eq(appointmentsTable.id, appointmentId)).run();
}

// --- Функції для управління знижками ---

/**
 * Автоматично застосувати знижку
 * @param originalPrice Початкова ціна
 * @param discount Знижка
 */
function applyDiscount(originalPrice: number, discount: Discount) {
    if (discount.discountType === 'PERCENTAGE') {
        return originalPrice - (originalPrice * discount.value / 100);
    } else if (discount.discountType === 'FIXED') {
        return Math.max(0, originalPrice - discount.value);
    }
    return originalPrice;
}

/**
 * Отримати всі активні знижки
 */
export async function getActiveDiscounts() {
    return db.select().from(discountsTable).where(eq(discountsTable.isActive, true)).all();
}

/**
 * Призначити знижку клієнту
 * @param clientId ID клієнта
 * @param discountId ID знижки
 */
export async function assignDiscountToClient(clientId: number, discountId: number) {
    return db.insert(clientDiscountsTable).values({
        clientId,
        discountId,
        appliedDate: new Date()
    }).run();
}

// --- Функції для історії ---

/**
 * Додати запис в історію відвідувань
 * @param clientId ID клієнта
 * @param appointmentId ID запису
 * @param amountPaid Сплачена сума
 */
export async function addVisitHistory(clientId: number, appointmentId: number, amountPaid: number) {
    return db.insert(visitHistoryTable).values({
        clientId,
        appointmentId,
        visitDate: new Date(),
        amountPaid
    }).run();
}

/**
 * Отримати історію відвідувань клієнта
 * @param clientId ID клієнта
 */
export async function getVisitHistory(clientId: number) {
    return db.select().from(visitHistoryTable).where(eq(visitHistoryTable.clientId, clientId)).all();
}

// --- Інші функції ---

/**
 * Отримати фінансовий звіт за період
 * @param startDate Дата початку
 * @param endDate Дата завершення
 */
export async function getFinancialReport(startDate: Date, endDate: Date) {
    const startDateISOString = startDate.toISOString();
    const endDateISOString = endDate.toISOString();

    return db.select({
        totalIncome: sum(visitHistoryTable.amountPaid)
    }).from(visitHistoryTable).where(
        and(
            sql`datetime(${visitHistoryTable.visitDate}) >= datetime(${startDateISOString})`,
            sql`datetime(${visitHistoryTable.visitDate}) <= datetime(${endDateISOString})`
        )
    ).get();
}


// Get all appointments
export const getAppointments = async () => {
    try {
        const result = await db
            .select({
                id: appointmentsTable.id,
                clientName: clientsTable.fullName,
                serviceName: servicesTable.name,
                appointmentDate: appointmentsTable.appointmentDate,
            })
            .from(appointmentsTable)
            .leftJoin(clientsTable, eq(appointmentsTable.clientId, clientsTable.clientId))
            .leftJoin(servicesTable, eq(appointmentsTable.serviceId, servicesTable.id));

        return result.map(row => ({
            id: row.id,
            title: `${row.clientName} - ${row.serviceName}`,
            start: new Date(row.appointmentDate).toISOString(),
        }));
    } catch (error) {
        console.error('Error fetching appointments:', error);
        throw error;
    }
};

// Create a new appointment
// export const createAppointment = async ({ clientId, serviceId, appointmentDate }: {
//     clientId: number;
//     serviceId: number;
//     appointmentDate: string; // ISO string
// }) => {
//     try {
//         // Check for overlapping appointments
//         const existingAppointment = await db
//             .select()
//             .from(appointments)
//             .where(
//                 and(
//                     eq(appointments.clientId, clientId),
//                     eq(appointments.serviceId, serviceId),
//                     eq(appointments.appointmentDate, new Date(appointmentDate))
//                 )
//             );
//
//         if (existingAppointment.length > 0) {
//             throw new Error('Appointment already exists for this client at this time.');
//         }
//
//         // Insert new appointment
//         await db.insert(appointments).values({
//             clientId,
//             serviceId,
//             appointmentDate: new Date(appointmentDate),
//             status: 'SCHEDULED',
//         });
//     } catch (error) {
//         console.error('Error creating appointment:', error);
//         throw error;
//     }
// };
