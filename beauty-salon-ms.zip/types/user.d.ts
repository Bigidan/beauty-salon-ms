export type User = {
    userId: number,
    role: number | null,
    name: string,
    phone: string,
    email: string,
    password: string,
}